using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    public int HP = 5;
    public float speed = 3;
    public Transform target;
    public SpriteRenderer Player;
    public float jumpforce = 3;
    public Rigidbody2D player;
    public float cooldown = 3;
    bool active;
    float LastJump = 3;
    
    



    // Update is called once per frame
    void Update()
    {
        if (HP <= 0)
        {
            Destroy(this.gameObject);
        }
        
        float Horizontal = Input.GetAxisRaw("Horizontal");
        target.position += Vector3.right * speed * Time.deltaTime * Horizontal;
        if (Horizontal >= 0)
        {
            Player.flipX = false;
        }
        else
            Player.flipX = true;

        LastJump = LastJump + Time.deltaTime;
        if (cooldown < LastJump)
        {
            active = true;
        }
        else
        {
            active = false;
            LastJump = LastJump + Time.deltaTime;
        }


        if (Input.GetKeyDown(KeyCode.Space) && active == true)
        {
            player.AddForce(Vector3.up * jumpforce);
            LastJump = 0;

        }


    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        

        if (other.gameObject.tag == "enemy")
        {
            HP--;
            Debug.Log("player hp" + HP);
           
        }
        

        if (other.gameObject.tag == "HeadCollider")
        {
            Debug.Log("HeadCollider hp");

            Destroy(other.gameObject);
        }
    }

    /*private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HeadCollider")
        {
            Debug.Log("HeadCollider hp");

            Destroy(collision.gameObject);
        }
    }*/
}
