using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spwaner : MonoBehaviour
{
    int spwanAmout = 10;
    public GameObject enemy;

    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < 1; i++)
        {
            Spawn();
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void Spawn()
    {
        Instantiate(enemy, new Vector3(Random.Range(4, -4), -2, 0), enemy.transform.rotation);
    }

    

    
}